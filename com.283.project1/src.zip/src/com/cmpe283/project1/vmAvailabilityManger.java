package com.cmpe283.project1;


public class vmAvailabilityManger {

	public static void main(String[] args) throws Exception{
		
		//vmMangment.vCenterInitialization();
		vmMangment.startThreads();
		
		
	}
}
